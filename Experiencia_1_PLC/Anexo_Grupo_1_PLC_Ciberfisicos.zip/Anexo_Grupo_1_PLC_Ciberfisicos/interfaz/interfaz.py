import asyncio
import logging
import time
import traceback
from datetime import datetime
import os
import pandas as pd
import streamlit as st
from asyncua import Client, ua
# El desarrollo de este código empleo Inteligencia Artificial (IA) para acelerar la implementación y mejorar la calidad del código. 
# Sin embargo, la lógica, estructura y funcionalidad fueron diseñadas y supervisadas por el equipo asegurar que se ajusten a los 
# requisitos del proyecto.
OPC_URL = "opc.tcp://172.17.10.5:4840/Mitsubishi/FX5-OPC"

# Mapeo exacto de Sensores (NodeId : Etiqueta)
NODOS_SENSORES = {
    "ns=1;i=14": ("Nivel pulpa celda 1", "m"),
    "ns=1;i=20": ("Flujo cola celda 1",  "m³/s"),
    
    "ns=1;i=15": ("Nivel pulpa celda 2", "m"),
    "ns=1;i=21": ("Flujo cola celda 2",  "m³/s"),
    
    "ns=1;i=16": ("Nivel pulpa celda 3", "m"),
    "ns=1;i=19": ("Flujo cola celda 3",  "m³/s"),
    
    "ns=1;i=17": ("Nivel pulpa celda 4", "m"),
    "ns=1;i=22": ("Flujo cola celda 4",  "m³/s"),
    "ns=1;i=18": ("Nivel pulpa celda 5", "m"),
    "ns=1;i=23": ("Flujo cola celda 5",  "m³/s"),
    
    "ns=1;i=24": ("Flujo de aire",       "m³/s"),
    "ns=1;i=25": ("Ley Concentrado",     "%"),
    "ns=1;i=26": ("Recuperacion",        "%"),
    "ns=1;i=27": ("Ley de entrada",      "%"),
    "ns=1;i=28": ("Ley de cola",         "%"),
}

def get_pid_nodes(idx):
    """
    Ajusta el índice base (i=29...) según el desplazamiento detectado:
    Si pides Celda 1 -> Usa bloque que empieza en i=35 (antigua celda 2)
    Si pides Celda 2 -> Usa bloque que empieza en i=41 (antigua celda 3)
    Si pides Celda 3 -> Usa bloque que empieza en i=29 (antigua celda 1)
    """
    if idx == 1:
        base_real = 35 
    elif idx == 2:
        base_real = 41 
    elif idx == 3:
        base_real = 29 
    else:

        base_real = 29 + (idx - 1) * 6
        
    return {
        "fSetpoint": f"ns=1;i={base_real}",
        "fPv":        f"ns=1;i={base_real + 1}",
        "fKp":        f"ns=1;i={base_real + 2}",
        "fTi":        f"ns=1;i={base_real + 3}",
        "fTd":        f"ns=1;i={base_real + 4}",
        "fOutput":    f"ns=1;i={base_real + 5}",
    }

def get_pid_nodes(idx):
    base = 29 + (idx - 1) * 6
    return {
        "fSetpoint": f"ns=1;i={base}",
        "fPv":       f"ns=1;i={base + 1}",
        "fKp":       f"ns=1;i={base + 2}",
        "fTi":       f"ns=1;i={base + 3}",
        "fTd":       f"ns=1;i={base + 4}",
        "fOutput":   f"ns=1;i={base + 5}",
    }

NODE_KP_BASE = "ns=1;i=9"
NODE_TI_BASE = "ns=1;i=10"
NODE_TD_BASE = "ns=1;i=11"
NODE_KFF     = "ns=1;i=12"

# ─── CORE DE COMUNICACIÓN ───────────────────────────────────────────────────

async def leer_nodos_bulk(node_ids):
    """Lee una lista de NodeIds en una sola petición (eficiente)."""
    async with Client(url=OPC_URL) as client:
        nodes = [client.get_node(nid) for nid in node_ids]
        return await client.read_values(nodes)

async def escribir_nodo(node_id, valor, tipo=ua.VariantType.Float):
    async with Client(url=OPC_URL) as client:
        node = client.get_node(node_id)
        await node.write_value(ua.DataValue(ua.Variant(float(valor), tipo)))

# ─── INTERFAZ DE DATOS PARA STREAMLIT ───────────────────────────────────────

def obtener_lecturas_sensores():
    try:
        nids = list(NODOS_SENSORES.keys())
        valores = asyncio.run(leer_nodos_bulk(nids))
        # Retornamos lista de diccionarios para facilitar el dataframe y las cards
        resultado = []
        for i, nid in enumerate(nids):
            nombre, unidad = NODOS_SENSORES[nid]
            resultado.append({"Variable": nombre, "Valor": valores[i], "Unidad": unidad, "NodeId": nid})
        return resultado, None
    except Exception as e:
        return None, str(e)

def leer_pid_completo(idx):
    try:
        mapping = get_pid_nodes(idx)
        nids = list(mapping.values())
        keys = list(mapping.keys())
        valores = asyncio.run(leer_nodos_bulk(nids))
        return {keys[i]: valores[i] for i in range(len(keys))}, None
    except Exception as e:
        return None, str(e)

# ─── STREAMLIT UI ───────────────────────────────────────────────────────────
st.set_page_config(page_title="Planta de Flotación CPS", layout="wide")

# Inicialización de estado
if "pid_data" not in st.session_state:
    st.session_state.pid_data = {i: {} for i in range(1, 6)}
if "historial" not in st.session_state:
    st.session_state.historial = {i: [] for i in range(1, 6)}

st.title(" Control Planta de Flotación")
st.caption(f"Conectado a: {OPC_URL}")

# --- SECCIÓN 1: SENSORES ---
st.subheader(" Monitoreo en Tiempo Real")
datos_sensores, err = obtener_lecturas_sensores()

if err:
    st.error(f"Error de conexión: {err}")
else:
    # Cards dinámicas para las 5 celdas
    cols = st.columns(5)
    for i in range(5):
        nivel = datos_sensores[i*2]["Valor"]
        flujo = datos_sensores[i*2 + 1]["Valor"]
        with cols[i]:
            st.metric(f"Celda {i+1} (Nivel)", f"{nivel:.3f} m")
            st.caption(f"Cola: {flujo:.3f} m³/s")
            # Guardar historial para gráfico
            st.session_state.historial[i+1].append(nivel)
            if len(st.session_state.historial[i+1]) > 50: st.session_state.historial[i+1].pop(0)

    st.divider()
    
    # Tabla de leyes y globales
    c_info, c_graf = st.columns([1, 2])
    with c_info:
        st.dataframe(pd.DataFrame(datos_sensores[10:]), hide_index=True, use_container_width=True)
    with c_graf:
        celda_sel = st.selectbox("Ver tendencia Celda:", [1,2,3,4,5])
        st.line_chart(st.session_state.historial[celda_sel])

# --- SECCIÓN 2: CONTROL PID ---
st.divider()
st.subheader("⚙️ Configuración PID")

tab1, tab2 = st.tabs(["Control por Celda", "Parámetros Globales"])

with tab1:
    idx_pid = st.radio("Seleccionar Celda:", [1,2,3,4,5], horizontal=True)
    
    col_btn, col_edit = st.columns([1, 3])
    
    with col_btn:
        if st.button(f"📥 Leer PID {idx_pid} desde PLC"):
            res, e = leer_pid_completo(idx_pid)
            if res: 
                st.session_state.pid_data[idx_pid] = res
                st.success("Leído")
            else: st.error(e)
            
    if st.session_state.pid_data[idx_pid]:
        d = st.session_state.pid_data[idx_pid]
        c1, c2, c3 = st.columns(3)
        new_sp = c1.number_input("Setpoint", value=float(d['fSetpoint']), key=f"sp_{idx_pid}")
        new_kp = c2.number_input("Kp", value=float(d['fKp']), key=f"kp_{idx_pid}")
        new_ti = c3.number_input("Ti", value=float(d['fTi']), key=f"ti_{idx_pid}")
        
        if st.button(f"📤 Enviar a Celda {idx_pid}", type="primary"):
            try:
                map_nodos = get_pid_nodes(idx_pid)
                asyncio.run(escribir_nodo(map_nodos["fSetpoint"], new_sp))
                asyncio.run(escribir_nodo(map_nodos["fKp"], new_kp))
                asyncio.run(escribir_nodo(map_nodos["fTi"], new_ti))
                st.success("Enviado con éxito")
            except Exception as e:
                st.error(f"Error al enviar: {e}")

with tab2:
    g1, g2, g3 = st.columns(3)
    gk = g1.number_input("Kp Global", value=-1.2)
    gt = g2.number_input("Ti Global", value=20.0)
    gff = g3.number_input("K FF", value=1.0)
    if st.button("Enviar Parámetros Base"):
        try:
            asyncio.run(escribir_nodo(NODE_KP_BASE, gk))
            asyncio.run(escribir_nodo(NODE_TI_BASE, gt))
            asyncio.run(escribir_nodo(NODE_KFF, gff))
            st.success("Globales actualizados")
        except Exception as e: st.error(e)

# Auto-refresh
time.sleep(2)
st.rerun()